Pokemon Space World Crystal vb4.2
by TSK

*New in vb4.2
*Gave Moltres a new event flag to prevent potential issue with it not showing up

*New in vb4.1
-Fixed an issue where defeating Mewtwo would cause Mew to never appear
-The Bug Catching Contest now awards a Poison Stone instead of a Sun Stone for first place
-The Odd Egg can now be Shiny again
-Catching a transformed Pokemon will no longer cause that Pokemon to become a Ditto

*New in vb4.0
-The Pokedex can now be completed within a single game, new areas have been added for some of the newly obtainable Pokemon
-Pokemon sprites now fade out properly
-The bike is now 2 times faster, running is the same speed as the old bike

*New in vb3.1
-The shiny odds are now calculated like in the prototype, the requirement is that the DV for ATK, DEF, SPD and SPC are above 10. Some of your old Pokemon may have turned shiny!
-Fixed a major bug in the Giga Training script which corrupts some party data when completing a Giga Training session
-Fixed a unit conversion issue for height in the Pokedex
-Fixed the "New" Pokedex order missing several species
-Fixed the current type chart setting not showing up on the save screen
-Gave Lykwyse the same breeding behaviour as Ditto
-Fixed Lykwyse having an incorrect gender ratio
-Fixed Ampharos no longer learning Thunder Punch on level up
-Fixed several instances of text referring to no longer included Pokemon

*New in vb3.0
-Added dex entries for all beta Pokemon
-Fixed Hoothoot's backsprite having an incorrect palette mapping

*New in vb2.0
-Fixed Eevee not evolving into Leafeon, now evolves with Leaf Stone
-Fixed Madame not having TM compatibility
-Added the option to choose between the finalized and beta type charts when starting a new game
-Added the option to switch type charts for an existing save, hold Down+B while starting the game
-Added a run button, hold B to go fast
-All evolution stones now for purchase in the Celadon city mart
-DV and Stat. EXP display in the blue page of the Pokemon menu, press select to toggle
-New NPC at the Mt. Silver Pokemon Center that lets you max the Stat EXP. and DVs of a Pokemon directly, but for a price

*Required
-a clean Pokemon Crystal(UE) (v1.1) ROM
-"Lunar IPS.exe" (provided)
-"Pokemon Space World Crystal vb3.1.ips" (provided)

*Instructions
-Open the "Lunar IPS.exe" executable
-Select "Apply IPS Patch"
-Select "Pokemon Space World Crystal vb4.0.ips" from the file selector
-Select your clean Pokemon Crystal(v1.1) ROM from the file selector(WARNING: this will overwrite your clean ROM)
